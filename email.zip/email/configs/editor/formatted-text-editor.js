const editor = require('@bsi-cx/design-standard-library-email/configs/editor/full');

// Add custom styles here
module.exports = editor.withTextColors('#ff00ff', '#ff0000', '#00ff00')
.withBackgroundColors('#ff00ff', '#ff0000', '#00ff00');