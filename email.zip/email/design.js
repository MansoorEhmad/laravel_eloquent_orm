require("./styles/styles.scss");

const { cx, SchemaVersion, Locale, Version } = require("@bsi-cx/design-build");

module.exports = cx.design
  .withSchemaVersion(SchemaVersion.V_22_0)
  .withTitle("BSI CX Master Template - E-Mail")
  .withAuthor("Design Team - BSI Business Systems Integration AG")
  .withDate("22.08.2022")
  .withPreviewImage("static/header-image.png")
  .withDefaultLocale(Locale.EN)
  .withLocales(Locale.EN)
  .withDropzones(
    cx.dropzone
      .withDropzone("header-2Hmmjt")
      .withAllowedElements(
        require("./content-elements/layout/1020-pink-banner/index.js"),
        require("./content-elements/layout/1020-link-image/index.js")
      ),
    cx.dropzone
      .withDropzone("body-3Bmmjt")
      .withAllowedElements(
        require("./content-elements/layout/3-column-flexi/index.js"),
        require("./content-elements/layout/2-column-flexi/index.js"),
        require("./content-elements/layout/2010-three-rows/index.js"),
        require("./content-elements/layout/2030-two-column/index.js"),
        require("./content-elements/layout/2050-two-column/index.js"),
        require("./content-elements/layout/2200-two-column/index.js"),
        require("./content-elements/layout/2400-two-column/index.js"),
        require("./content-elements/layout/4020-two-column/index.js"),
        require("./content-elements/layout/2300-two-rows/index.js"),
        require("./content-elements/layout/2080-image/index.js"),
        require("./content-elements/layout/2910-text/index.js"),
        require("./content-elements/layout/2901-btn/index.js"),
        require("./content-elements/layout/2902-full-btn/index.js"),
        require("./content-elements/layout/2907-text-link/index.js")
      ),
    cx.dropzone
      .withDropzone("footer-2Fmmjt")
      .withAllowedElements(
        require("./content-elements/layout/3990-footer/index.js"),
        require("./content-elements/layout/3010-three-rows/index.js")
      )
  )
  .withContentElementGroups(
    cx.contentElementGroup
      .withGroupId("custom-content-1020-pink-banner-PBK123")
      .withLabel("1020 pink banner section")
      .withContentElements(
        require("./content-elements/layout/1020-pink-banner/index.js"),
        require("./content-elements/layout/1020-pink-banner/banner/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-1020-link-image-LIL123")
      .withLabel("1020 link image section")
      .withContentElements(
        require("./content-elements/layout/1020-link-image/index.js"),
        require("./content-elements/layout/1020-link-image/link-image/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2-column-flexi-TCFS123")
      .withLabel("two column flexi")
      .withContentElements(
        require("./content-elements/layout/2-column-flexi/index.js"),
        require("./content-elements/layout/2-column-flexi/column-flexi-img/index.js"),
        require("./content-elements/layout/2-column-flexi/column-flexi-small-heading/index.js"),
        require("./content-elements/layout/2-column-flexi/column-flexi-big-heading/index.js"),
        require("./content-elements/layout/2-column-flexi/column-flexi-text/index.js"),
        require("./content-elements/layout/2-column-flexi/column-flexi-link-text/index.js"),
        require("./content-elements/layout/2-column-flexi/column-flexi-cta/index.js"),
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-3-column-flexi-TCFL123")
      .withLabel("three column flexi")
      .withContentElements(
        require("./content-elements/layout/3-column-flexi/index.js"),
        require("./content-elements/layout/3-column-flexi/column-flexi-img/index.js"),
        require("./content-elements/layout/3-column-flexi/column-flexi-small-heading/index.js"),
        require("./content-elements/layout/3-column-flexi/column-flexi-big-heading/index.js"),
        require("./content-elements/layout/3-column-flexi/column-flexi-text/index.js"),
        require("./content-elements/layout/3-column-flexi/column-flexi-link-text/index.js"),
        require("./content-elements/layout/3-column-flexi/column-flexi-cta/index.js"),
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2010-three-rows-TrC123")
      .withLabel("2010 three rows section")
      .withContentElements(
        require("./content-elements/layout/2010-three-rows/index.js"),
        require("./content-elements/layout/2010-three-rows/first/index.js"),
        require("./content-elements/layout/2010-three-rows/second/index.js"),
        require("./content-elements/layout/2010-three-rows/third/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2030-two-column-XyK123")
      .withLabel("2030 two columns section")
      .withContentElements(
        require("./content-elements/layout/2030-two-column/index.js"),
        require("./content-elements/layout/2030-two-column/image/index.js"),
        require("./content-elements/layout/2030-two-column/text/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2050-two-columns-TcK123")
      .withLabel("2050 two columns section")
      .withContentElements(
        require("./content-elements/layout/2050-two-column/index.js"),
        require("./content-elements/layout/2050-two-column/column/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2200-two-columns-TcW123")
      .withLabel("2200 two columns section")
      .withContentElements(
        require("./content-elements/layout/2200-two-column/index.js"),
        require("./content-elements/layout/2200-two-column/heading/index.js"),
        require("./content-elements/layout/2200-two-column/heading-two/index.js"),
        require("./content-elements/layout/2200-two-column/heading-three/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2400-two-columns-TcA123")
      .withLabel("2400 two columns section")
      .withContentElements(
        require("./content-elements/layout/2400-two-column/index.js"),
        require("./content-elements/layout/2400-two-column/left/index.js"),
        require("./content-elements/layout/2400-two-column/right/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-4020-two-columns-TcB123")
      .withLabel("4020 two columns section")
      .withContentElements(
        require("./content-elements/layout/4020-two-column/index.js"),
        require("./content-elements/layout/4020-two-column/left/index.js"),
        require("./content-elements/layout/4020-two-column/right/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2300-two-rows-TrD123")
      .withLabel("2300 two rows section")
      .withContentElements(
        require("./content-elements/layout/2300-two-rows/index.js"),
        require("./content-elements/layout/2300-two-rows/first/index.js"),
        require("./content-elements/layout/2300-two-rows/second/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2080-image-IFI123")
      .withLabel("2080 image section")
      .withContentElements(
        require("./content-elements/layout/2080-image/index.js"),
        require("./content-elements/layout/2080-image/image/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2910-text-TFJ123")
      .withLabel("2910 text section")
      .withContentElements(
        require("./content-elements/layout/2910-text/index.js"),
        require("./content-elements/layout/2910-text/text/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2901-btn-BG123")
      .withLabel("2901 btn section")
      .withContentElements(
        require("./content-elements/layout/2901-btn/index.js"),
        require("./content-elements/layout/2901-btn/btn/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2902-full-btn-FBH123")
      .withLabel("2902 full btn section")
      .withContentElements(
        require("./content-elements/layout/2902-full-btn/index.js"),
        require("./content-elements/layout/2902-full-btn/btn/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-2907-text-links-TlF123")
      .withLabel("2907 text links section")
      .withContentElements(
        require("./content-elements/layout/2907-text-link/index.js"),
        require("./content-elements/layout/2907-text-link/text-links/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-3990-footer-text-FtF123")
      .withLabel("3990 footer text section")
      .withContentElements(
        require("./content-elements/layout/3990-footer/index.js"),
        require("./content-elements/layout/3990-footer/text/index.js")
      ),
    cx.contentElementGroup
      .withGroupId("custom-content-3010-three-rows-TrE123")
      .withLabel("3010 three rows section")
      .withContentElements(
        require("./content-elements/layout/3010-three-rows/index.js"),
        require("./content-elements/layout/3010-three-rows/first/index.js"),
        require("./content-elements/layout/3010-three-rows/first-second/index.js"),
        require("./content-elements/layout/3010-three-rows/second/index.js"),
        require("./content-elements/layout/3010-three-rows/third/index.js")
      )
  );