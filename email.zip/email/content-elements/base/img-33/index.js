const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/image/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'img-33-3NPzOS',
  /*'Image',*/
  'Bild',
  /*'33% width',*/
  '33% Breite',
  'img-33-part-image-gv8VXl',
  /*'Image',*/
  'Bild',
  'img-33-part-text-8Cfh88',
  /*'Caption'*/
  'Bildunterschrift'
);