const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/image/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'img-66-k7NeCN',
  /*'Image',*/
  'Bild',
  /*'66% width',*/
  '66% Breite',
  'img-66-part-image-8ccJLv',
  /*'Image',*/
  'Bild',
  'img-66-part-text-X4GktA',
  /*'Caption'*/
  'Bildunterschrift'
);