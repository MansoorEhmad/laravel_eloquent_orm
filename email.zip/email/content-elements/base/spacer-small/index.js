const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/spacer/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'spacer-small-8eA0T7',
  /*'Spacing small'*/
  'Abstand - klein'
);