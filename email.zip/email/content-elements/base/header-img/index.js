const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/header-img/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'header-img-GTzJdB',
  /*'Header image',*/
  'Header Bild',
  'header-img-part-nMiDJj',
  /*'Header image'*/
  'Header Bild'
);