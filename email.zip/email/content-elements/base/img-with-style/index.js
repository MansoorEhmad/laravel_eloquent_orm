const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/image/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'img-with-style-wsFfey',
  /*'Image',*/
  'Bild',
  '33%, 50%, 66% oder 100% Breite',
  'img-with-style-part-image-Myqp3Q',
  /*'Image',*/
  'Bild',
  'img-with-style-part-text-lVGDeP',
  /*'Caption'*/
  'Bildunterschrift'
);