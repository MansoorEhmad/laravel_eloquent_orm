const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/cta/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'cta-center-CLc9J9',
  /*'CTA button',*/
  'CTA Button',
  /*'center aligned',*/
  'mittig',
  'cta-center-part-qt8DLo',
  /*'CTA button'*/
  'CTA Button'
);