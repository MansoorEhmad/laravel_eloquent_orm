const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/header-logo/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'logo-TlgUGB',
  'Logo',
  'logo-part-ss4YMw',
  'Logo'
);