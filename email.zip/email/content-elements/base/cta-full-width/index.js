const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/cta/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'cta-full-width-qsvPcs',
  /*'CTA button',*/
  'CTA Button',
  /*'full width',*/
  'ganze Breite',
  'cta-full-width-part-R7DcqB',
  /*'CTA button'*/
  'CTA Button'
).withStyleConfigs();