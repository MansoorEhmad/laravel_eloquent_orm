const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/cta/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'cta-right-iVLOnT',
  /*'CTA button',*/
  'CTA Button',
  /*'right aligned',*/
  'rechtsbündig',
  'cta-right-part-iSIdKD',
  /*'CTA button'*/
  'CTA Button'
);