const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/image/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'img-50-TcxfeC',
  /*'Image',*/
  'Bild',
  /*'50% width',*/
  '50% Breite',
  'img-50-part-image-hTFuUC',
  /*'Image',*/
  'Bild',
  'img-50-part-text-egPKon',
  /*'Caption'*/
  'Bildunterschrift'
);