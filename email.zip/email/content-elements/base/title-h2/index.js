const contentElement = require('@bsi-cx/design-standard-library-email/content-elements/base/title-h1/prototype');

module.exports = contentElement(
  require('./template.twig'),
  'title-h2-BkcTSM',
  /*'Heading 2',*/
  'Titel 2',
  'title-h2-part-n72LIp',
  /*'Heading 2'*/
  'Titel 2'
);