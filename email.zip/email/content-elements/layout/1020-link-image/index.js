require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('1020-link-image-element-id')
  .withLabel('1020 link image')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('1020-link-image-dropzone-id')
    .withAllowedElements(
      require('./link-image'))
    .withMaxAllowedElements(1),
  );