const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('1020-link-image-inner-element-id')
  .withLabel('1020 link image')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('1020-link-image-inner-text-part-id')
      .withLabel('text'),
    cx.part.image
      .withId('1020-link-image-inner-image-part-id')
      .withLabel('image'),
);