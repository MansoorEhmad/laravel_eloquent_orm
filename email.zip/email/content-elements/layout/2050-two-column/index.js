require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2050-two-column-element-id')
  .withLabel('2050 two columns')
  .withIcon(Icon.TWO_COLUMNS)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('2050-two-column-dropzone-left-id')
    .withAllowedElements(
      require('./column'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('2050-two-column-dropzone-right-id')
    .withAllowedElements(
      require('./column'))
    .withMaxAllowedElements(1),
  );