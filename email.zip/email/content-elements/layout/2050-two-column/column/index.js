const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2050-two-column-inner-element-id')
  .withLabel('2050 column')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.image
      .withId('2050-two-column-inner-image-part-id')
      .withLabel('image'),
    cx.part.formattedText
      .withId('2050-two-column-inner-small-heading-part-id')
      .withLabel('small heading'),
    cx.part.formattedText
      .withId('2050-two-column-inner-big-heading-part-id')
      .withLabel('big heading'),
    cx.part.formattedText
      .withId('2050-two-column-inner-para-part-id')
      .withLabel('paragraph'),
    cx.part.formattedText
      .withId('2050-two-column-inner-price1-part-id')
      .withLabel('price one'),
    cx.part.formattedText
      .withId('2050-two-column-inner-price2-part-id')
      .withLabel('price two'),
    cx.part.link
      .withId('2050-two-column-inner-link-part-id')
      .withLabel('link text'),
    cx.part.link
      .withId('2050-two-column-inner-btn-part-id')
      .withLabel('btn'),
  );