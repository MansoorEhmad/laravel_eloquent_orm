const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('3990-footer-inner-text-element-id')
  .withLabel('3990 footer text')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('3990-footer-inner-text-part-id')
      .withLabel('text'),
);