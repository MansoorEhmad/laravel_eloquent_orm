require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('3990-footer-text-element-id')
  .withLabel('3990 footer text')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('3990-footer-text-dropzone-id')
    .withAllowedElements(
      require('./text'))
    .withMaxAllowedElements(1),
  );