const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('three-column-flexi-inner-text-element-id')
  .withLabel('three column flexi text')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('three-column-flexi-inner-text-part-id')
      .withLabel('text')
      .withHtmlEditorConfig(require('./../../../../configs/editor/formatted-text-editor'))
  );