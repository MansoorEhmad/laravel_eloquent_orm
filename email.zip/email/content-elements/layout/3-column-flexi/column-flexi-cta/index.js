const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('three-column-flexi-inner-cta-element-id')
  .withLabel('three column flexi cta')
  .withIcon(Icon.MEGAPHONE)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('three-column-flexi-inner-cta-part-id')
      .withLabel('cta')
  )
  .withStyleConfigs(require('./ctaColor.js'));