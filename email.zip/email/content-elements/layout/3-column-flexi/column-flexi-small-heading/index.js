const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('three-column-flexi-inner-small-heading-element-id')
  .withLabel('three column flexi small heading')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('three-column-flexi-inner-small-heading-part-id')
      .withLabel('small heading')
  );