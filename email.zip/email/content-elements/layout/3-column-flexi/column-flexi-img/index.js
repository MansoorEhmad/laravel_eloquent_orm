const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('three-column-flexi-inner-img-element-id')
  .withLabel('three column flexi img')
  .withIcon(Icon.IMAGE)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.image
      .withId('three-column-flexi-inner-img-part-id')
      .withLabel('image')
  );