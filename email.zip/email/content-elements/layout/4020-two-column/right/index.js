const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('4020-two-column-inner-right-element-id')
  .withLabel('4020 right column')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('4020-two-column-inner-right-btn-part-id')
      .withLabel('btn'),
);