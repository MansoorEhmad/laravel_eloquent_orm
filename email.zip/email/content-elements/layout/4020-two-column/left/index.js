const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('4020-two-column-inner-left-element-id')
  .withLabel('4020 left column')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.image
      .withId('4020-two-column-inner-left-image-part-id')
      .withLabel('image'),
    cx.part.formattedText
      .withId('4020-two-column-inner-left-title-part-id')
      .withLabel('title'),
    cx.part.formattedText
      .withId('4020-two-column-inner-left-old-price-part-id')
      .withLabel('old price'),
    cx.part.formattedText
      .withId('4020-two-column-inner-left-new-price-part-id')
      .withLabel('new price'),
);