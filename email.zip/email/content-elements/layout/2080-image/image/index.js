const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2080-image-inner-element-id')
  .withLabel('2080 image')
  .withIcon(Icon.IMAGE)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.image
      .withId('2080-image-inner-part-id')
      .withLabel('image'),
);