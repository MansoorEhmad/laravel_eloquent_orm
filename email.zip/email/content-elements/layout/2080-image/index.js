require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2080-image-element-id')
  .withLabel('2080 image')
  .withIcon(Icon.IMAGE)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('2080-image-dropzone-id')
    .withAllowedElements(
      require('./image'))
    .withMaxAllowedElements(1),
  );