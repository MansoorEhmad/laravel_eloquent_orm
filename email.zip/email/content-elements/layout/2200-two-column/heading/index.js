const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2200-two-column-inner-element-id')
  .withLabel('2200 heading')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('2200-two-column-inner-big-heading-part-id')
      .withLabel('big heading'),
    cx.part.formattedText
      .withId('2200-two-column-inner-small-heading-part-id')
      .withLabel('small heading'),
);