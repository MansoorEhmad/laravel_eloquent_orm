const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2200-two-column-inner-heading2-element-id')
  .withLabel('2200 left body')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('2200-two-column-inner-big-heading2-part-id')
      .withLabel('big heading'),
    cx.part.formattedText
      .withId('2200-two-column-inner-para-part-id')
      .withLabel('paragraph'),
    cx.part.formattedText
      .withId('2200-two-column-inner-bold-text-part-id')
      .withLabel('bold text'),
    cx.part.formattedText
      .withId('2200-two-column-inner-small-text-part-id')
      .withLabel('small text'),
);