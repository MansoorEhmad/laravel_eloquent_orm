const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2200-two-column-inner-heading3-element-id')
  .withLabel('2200 right body')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('2200-two-column-inner-big-heading3-part-id')
      .withLabel('big heading'),
    cx.part.formattedText
      .withId('2200-two-column-inner-para2-part-id')
      .withLabel('paragraph'),
);