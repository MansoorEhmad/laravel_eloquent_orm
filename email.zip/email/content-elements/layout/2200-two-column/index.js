require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2200-two-column-element-id')
  .withLabel('2200 two columns')
  .withIcon(Icon.TWO_COLUMNS)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('2200-two-column-dropzone-heading-id')
    .withAllowedElements(
      require('./heading'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('2200-two-column-dropzone-heading1-id')
    .withAllowedElements(
      require('./heading'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('2200-two-column-dropzone-heading2-id')
    .withAllowedElements(
      require('./heading-two'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('2200-two-column-dropzone-heading2-1-id')
    .withAllowedElements(
      require('./heading-three'))
    .withMaxAllowedElements(1),
  );