const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('two-column-flexi-inner-text-element-id')
  .withLabel('two column flexi text')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('two-column-flexi-inner-text-part-id')
      .withLabel('text')
      .withHtmlEditorConfig(require('./../../../../configs/editor/formatted-text-editor'))
  );