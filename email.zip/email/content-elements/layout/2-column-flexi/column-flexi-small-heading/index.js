const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('two-column-flexi-inner-small-heading-element-id')
  .withLabel('two column flexi small heading')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('two-column-flexi-inner-small-heading-part-id')
      .withLabel('small heading')
  );