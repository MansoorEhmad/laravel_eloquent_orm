const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('two-column-flexi-inner-cta-element-id')
  .withLabel('two column flexi cta')
  .withIcon(Icon.MEGAPHONE)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('two-column-flexi-inner-cta-part-id')
      .withLabel('cta')
  )
  .withStyleConfigs(require('./ctaColor.js'));