const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('two-column-flexi-inner-link-text-element-id')
  .withLabel('two column flexi link text')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('two-column-flexi-inner-link-text-part-id')
      .withLabel('link text')
  );