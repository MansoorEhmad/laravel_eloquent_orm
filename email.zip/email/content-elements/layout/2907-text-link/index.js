require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2907-text-links-element-id')
  .withLabel('2907 text links')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('2907-text-links-dropzone-id')
    .withAllowedElements(
      require('./text-links'))
    .withMaxAllowedElements(1),
  );