const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2907-text-links-inner-element-id')
  .withLabel('2907 text links')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('2907-text-links-inner-one-part-id')
      .withLabel('text link one'),
    cx.part.link
      .withId('2907-text-links-inner-two-part-id')
      .withLabel('text link two'),
    cx.part.link
      .withId('2907-text-links-inner-three-part-id')
      .withLabel('text link three'),
);