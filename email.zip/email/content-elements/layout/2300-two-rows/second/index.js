const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2300-two-rows-inner-second-element-id')
  .withLabel('2300 second row')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.image
      .withId('2300-two-rows-inner-second-image-part-id')
      .withLabel('image'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-title-part-id')
      .withLabel('title'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-para-part-id')
      .withLabel('paragraph'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-blur-text-one-part-id')
      .withLabel('blur text one'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-text-one-part-id')
      .withLabel('text one'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-blur-text-two-part-id')
      .withLabel('blur text two'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-text-two-part-id')
      .withLabel('text two'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-blur-text-three-part-id')
      .withLabel('blur text three'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-text-three-part-id')
      .withLabel('text three'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-blur-text-four-part-id')
      .withLabel('blur text four'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-second-text-four-part-id')
      .withLabel('text four'),
);