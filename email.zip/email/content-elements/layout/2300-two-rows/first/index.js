const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2300-two-rows-inner-first-element-id')
  .withLabel('2300 first row')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('2300-two-rows-inner-first-bold-text-part-id')
      .withLabel('bold text'),
    cx.part.formattedText
      .withId('2300-two-rows-inner-first-small-text-part-id')
      .withLabel('small text'),
);