require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2300-two-rows-element-id')
  .withLabel('2300 two rows')
  .withIcon(Icon.TWO_COLUMNS)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('2300-two-rows-dropzone-first-left-id')
    .withAllowedElements(
      require('./first'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('2300-two-rows-dropzone-first-right-id')
    .withAllowedElements(
      require('./first'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('2300-two-rows-dropzone-second-first-id')
    .withAllowedElements(
      require('./second'))
    .withMaxAllowedElements(1),
  );