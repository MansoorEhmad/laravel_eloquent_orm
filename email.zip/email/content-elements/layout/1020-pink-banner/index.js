require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('1020-pink-banner-element-id')
  .withLabel('1020 pink banner')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('1020-pink-banner-dropzone-id')
    .withAllowedElements(
      require('./banner'))
    .withMaxAllowedElements(1),
  );