const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('1020-pink-banner-inner-element-id')
  .withLabel('1020 banner')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('1020-pink-banner-inner-text-part-id')
      .withLabel('text'),
    cx.part.image
      .withId('1020-pink-banner-inner-image-part-id')
      .withLabel('image'),
);