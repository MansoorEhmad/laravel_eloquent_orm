const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2030-two-column-inner-right-element-id')
  .withLabel('2030 right section')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('2030-two-column-inner-title-part-id')
      .withLabel('small heading'),
    cx.part.formattedText
      .withId('2030-two-column-inner-title2-part-id')
      .withLabel('big heading'),
    cx.part.formattedText
      .withId('2030-two-column-inner-para-part-id')
      .withLabel('paragraph'),
    cx.part.formattedText
      .withId('2030-two-column-inner-text-part-id')
      .withLabel('link text'),
    cx.part.link
      .withId('2030-two-column-inner-btn-part-id')
      .withLabel('btn')
  );