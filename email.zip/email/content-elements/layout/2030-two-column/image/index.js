const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2030-two-column-inner-image-element-id')
  .withLabel('2030 column left image')
  .withIcon(Icon.IMAGE)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.image
      .withId('2030-two-column-inner-image-part-id')
      .withLabel('2030 column left image')
  );