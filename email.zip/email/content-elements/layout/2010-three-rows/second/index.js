const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2010-three-rows-inner-second-element-id')
  .withLabel('2010 second row')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('2010-three-rows-inner-second-link-one-part-id')
      .withLabel('link one'),
    cx.part.link
      .withId('2010-three-rows-inner-second-link-two-part-id')
      .withLabel('link second'),
    cx.part.link
      .withId('2010-three-rows-inner-second-link-three-part-id')
      .withLabel('link third'),
);