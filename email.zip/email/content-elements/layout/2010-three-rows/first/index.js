const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2010-three-rows-inner-first-element-id')
  .withLabel('2010 first row')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.image
      .withId('2010-three-rows-inner-first-image-part-id')
      .withLabel('image'),
    cx.part.formattedText
      .withId('2010-three-rows-inner-first-small-heading-part-id')
      .withLabel('small heading'),
    cx.part.formattedText
      .withId('2010-three-rows-inner-first-big-heading-part-id')
      .withLabel('big heading'),
    cx.part.formattedText
      .withId('2010-three-rows-inner-first-para-part-id')
      .withLabel('paragraph'),
    cx.part.formattedText
      .withId('2010-three-rows-inner-first-points-part-id')
      .withLabel('unordered list'),
);