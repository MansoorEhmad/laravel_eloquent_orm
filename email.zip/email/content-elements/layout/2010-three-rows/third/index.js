const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2010-three-rows-inner-third-element-id')
  .withLabel('2010 third row')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('2010-three-rows-inner-third-btn1-part-id')
      .withLabel('btn one'),
    cx.part.link
      .withId('2010-three-rows-inner-third-btn2-part-id')
      .withLabel('btn second'),
    cx.part.link
      .withId('2010-three-rows-inner-third-btn3-part-id')
      .withLabel('btn third'),
);