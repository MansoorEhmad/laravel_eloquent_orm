require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2901-btn-element-id')
  .withLabel('2901 btn')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('2901-btn-dropzone-id')
    .withAllowedElements(
      require('./btn'))
    .withMaxAllowedElements(1),
  );