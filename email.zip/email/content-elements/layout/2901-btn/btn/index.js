const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2901-btn-inner-element-id')
  .withLabel('2901 btn')
  .withIcon(Icon.MEGAPHONE)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('2901-btn-inner-cta-part-id')
      .withLabel('btn'),
);