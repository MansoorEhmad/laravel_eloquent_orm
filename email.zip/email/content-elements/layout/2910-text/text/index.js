const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2910-text-inner-element-id')
  .withLabel('2910 text')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('2910-text-inner-part-id')
      .withLabel('text'),
);