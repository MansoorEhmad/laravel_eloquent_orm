require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2910-text-element-id')
  .withLabel('2910 text')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('2910-text-dropzone-id')
    .withAllowedElements(
      require('./text'))
    .withMaxAllowedElements(1),
  );