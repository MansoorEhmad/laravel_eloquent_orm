const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2400-two-column-inner-right-element-id')
  .withLabel('2400 right column')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('2400-two-column-inner-right-text-part-id')
      .withLabel('text'),
    cx.part.formattedText
      .withId('2400-two-column-inner-right-bold-text-part-id')
      .withLabel('bold text'),
);