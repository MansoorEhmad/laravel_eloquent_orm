const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2400-two-column-inner-left-element-id')
  .withLabel('2400 left column')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('2400-two-column-inner-left-text-part-id')
      .withLabel('text'),
    cx.part.formattedText
      .withId('2400-two-column-inner-left-bold-text-part-id')
      .withLabel('bold text'),
    cx.part.formattedText
      .withId('2400-two-column-inner-left-small-text-part-id')
      .withLabel('small text'),
    cx.part.link
      .withId('2400-two-column-inner-left-btn-part-id')
      .withLabel('small text'),
);