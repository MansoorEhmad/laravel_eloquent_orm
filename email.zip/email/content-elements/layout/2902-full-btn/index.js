require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('2902-full-btn-element-id')
  .withLabel('2902 full btn')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('2902-full-btn-dropzone-id')
    .withAllowedElements(
      require('./btn'))
    .withMaxAllowedElements(1),
  );