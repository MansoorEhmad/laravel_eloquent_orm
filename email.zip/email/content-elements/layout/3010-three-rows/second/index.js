const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('3010-three-rows-inner-second-element-id')
  .withLabel('3010 second row')
  .withIcon(Icon.TEXT)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.formattedText
      .withId('3010-three-rows-inner-second-text-part-id')
      .withLabel('text'),
);