require('./styles.less');
const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('3010-three-rows-element-id')
  .withLabel('3010 three rows')
  .withIcon(Icon.TWO_COLUMNS)
  .withFile(require('./template.twig'))
  .withDropzones(
    cx.dropzone
    .withDropzone('3010-three-rows-dropzone-first-id')
    .withAllowedElements(
      require('./first'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('3010-three-rows-dropzone-first-second-id')
    .withAllowedElements(
      require('./first-second'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('3010-three-rows-dropzone-second-id')
    .withAllowedElements(
      require('./second'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('3010-three-rows-dropzone-second-second-id')
    .withAllowedElements(
      require('./second'))
    .withMaxAllowedElements(1),
    cx.dropzone
    .withDropzone('3010-three-rows-dropzone-third-id')
    .withAllowedElements(
      require('./third'))
    .withMaxAllowedElements(1),
  );