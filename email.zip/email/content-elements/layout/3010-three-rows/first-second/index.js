const { cx, Icon, image, formattedText } = require('@bsi-cx/design-build');

module.exports = cx.contentElement
  .withElementId('3010-three-rows-inner-first-second-element-id')
  .withLabel('3010 first second row')
  .withIcon(Icon.ONE_COLUMN)
  .withFile(require('./template.twig'))
  .withParts(
    cx.part.link
      .withId('3010-three-rows-inner-first-second-text-one-part-id')
      .withLabel('link one'),
    cx.part.image
      .withId('3010-three-rows-inner-first-second-image-one-part-id')
      .withLabel('image one'),
    cx.part.link
      .withId('3010-three-rows-inner-first-second-text-two-part-id')
      .withLabel('link two'),
    cx.part.image
      .withId('3010-three-rows-inner-first-second-image-two-part-id')
      .withLabel('image two'),
    cx.part.link
      .withId('3010-three-rows-inner-first-second-text-three-part-id')
      .withLabel('link three'),
    cx.part.image
      .withId('3010-three-rows-inner-first-second-image-three-part-id')
      .withLabel('image three'),
    cx.part.link
      .withId('3010-three-rows-inner-first-second-text-four-part-id')
      .withLabel('link four'),
    cx.part.image
      .withId('3010-three-rows-inner-first-second-image-four-part-id')
      .withLabel('image four'),
);